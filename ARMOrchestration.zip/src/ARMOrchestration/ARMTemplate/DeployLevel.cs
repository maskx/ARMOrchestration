﻿namespace maskx.ARMOrchestration.ARMTemplate
{
    public enum DeployLevel
    {
        ResourceGroup,
        Subscription,
        ManagemnetGroup,
    }
}