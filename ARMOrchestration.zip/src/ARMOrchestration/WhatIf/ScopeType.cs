﻿namespace maskx.ARMOrchestration.WhatIf
{
    /// <summary>
    ///
    /// </summary>
    public enum ScopeType
    {
        Subscription,
        ResourceGroup
    }
}