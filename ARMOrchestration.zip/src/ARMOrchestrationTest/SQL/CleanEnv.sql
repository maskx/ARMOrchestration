﻿truncate table arm_Communication
drop table ARM_DeploymentOperations
drop table arm_Message
drop table arm_OrchestrationState
drop table arm_Session
drop table arm_SessionMessage
drop table ARM_WaitDependsOn
drop table arm_WorkItem