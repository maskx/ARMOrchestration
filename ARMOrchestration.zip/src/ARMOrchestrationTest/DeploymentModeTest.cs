﻿namespace ARMCreatorTest
{
    public class DeploymentModeTest
    {
    }
}